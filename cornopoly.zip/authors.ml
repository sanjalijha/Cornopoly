let hours_worked = [50; 50; 50]
